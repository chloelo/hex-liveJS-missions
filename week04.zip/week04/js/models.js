export default {
  template: '#model-update',
  data() {
    return {

    }
  }
}