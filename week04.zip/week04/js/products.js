const uuid = "27645507-6c88-4d1b-816f-1587210ac2be";
const apiPath = 'https://course-ec-api.hexschool.io/api/';
const app = new Vue({
  el: '#app',
  data() {
    return {
      user: {
        email: '',
        password: '',
      },
      token: '',
      products: [
        {
          id: '',
          title: '',
          category: '',
          content: '',
          description: '',
          imageUrl: [],
          enabled: true,
          origin_price: 0,
          price: 0,
          unit: "",
          options: {

          },
        },
      ],
    }
  },
  methods: {
    signout() {
      // 清除 Token
      document.cookie = `myToken=; expires=; path=/`;
      location.href = "login.html";
    },


  },
  mounted() {
    // 如果沒有token 表示沒有登入，轉跳回登入頁
    this.token = document.cookie.replace(/(?:(?:^|.*;\s*)myToken\s*\=\s*([^;]*).*$)|^.*$/, "$1");
    if (!this.token) {
      location.href = "login.html";
    }


    // API
    const api = `${apiPath}${uuid}/admin/ec/products`
    // 將 Token 加入到 Headers 內
    axios.defaults.headers.common['Authorization'] = `Bearer ${this.token}`;
    axios.get(api)
      .then(res => {
        this.products = res.data.data;

        console.log(this.products);
      }).catch(err => {
        console.log(err);
      })
  },
})