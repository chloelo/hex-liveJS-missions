const apiPath = 'https://course-ec-api.hexschool.io/api/';
const app = new Vue({
  el: '#app',
  data() {
    return {
      user: {
        token: '',
        uuid: '27645507-6c88-4d1b-816f-1587210ac2be'
      },

      products: [
        // {
        //   id: '',
        //   title: '',
        //   category: '',
        //   content: '',
        //   description: '',
        //   imageUrl: [],
        //   enabled: true,
        //   origin_price: 0,
        //   price: 0,
        //   unit: "",
        //   options: {

        //   },
        // },
      ],
      pagination: {},
      tempProduct: {}
    }
  },
  methods: {
    // 登出，清除 cookie 裡的 token
    signout() {
      // 清除 Token
      document.cookie = `myToken=; expires=; path=/`;
      location.href = "login.html";
    },
    // 取得產品列表
    getProducts() {
      // API
      const api = `${apiPath}${this.user.uuid}/admin/ec/products`
      // 將 Token 加入到 Headers 內
      axios.defaults.headers.common['Authorization'] = `Bearer ${this.user.token}`;
      axios.get(api)
        .then(res => {
          this.products = res.data.data;
          this.pagination = res.data.meta.pagination;
          console.log(res);
          console.log(this.pagination);
        }).catch(err => {
          console.log(err);
        })
    },

    openModal(status, product) {
      switch (status) {
        case 'add':
          this.tempProduct = {};
          $('#productModal').modal('show');

          break;
        case 'edit':

          this.getProduct(product.id);
          break;
        case 'del':
          this.tempProduct = JSON.parse(JSON.stringify(product));
          $('#delProductModal').modal('show');
          break;
        default:
          break;
      }

    },
    // 點擊編輯按鈕 -> 透過 AJAX 取得選取的的產品
    getProduct(id) {
      const api = `${apiPath}${this.user.uuid}/admin/ec/product/${id}`;
      axios.get(api)
        .then(res => {
          this.tempProduct = res.data.data;
          console.log(this.tempProduct);
        })
      $('#productModal').modal('show');
    },
  },
  mounted() {
    // 如果沒有token 表示沒有登入，轉跳回登入頁
    this.user.token = document.cookie.replace(/(?:(?:^|.*;\s*)myToken\s*\=\s*([^;]*).*$)|^.*$/, "$1");
    if (!this.user.token) {
      location.href = "login.html";
    }

    this.getProducts();


  },
})